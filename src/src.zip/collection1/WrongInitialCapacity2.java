package collection1;
public class WrongInitialCapacity2  extends RuntimeException{

    public WrongInitialCapacity2(String mess){
        super(mess);

    }
    
}
