public class WrongInitialCapacity  extends RuntimeException{

    public WrongInitialCapacity(String mess){
        super(mess);

    }
    
}
